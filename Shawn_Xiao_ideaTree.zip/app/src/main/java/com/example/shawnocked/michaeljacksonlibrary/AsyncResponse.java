package com.example.shawnocked.michaeljacksonlibrary;

interface AsyncResponse {
    void processFinish(String output);
}
